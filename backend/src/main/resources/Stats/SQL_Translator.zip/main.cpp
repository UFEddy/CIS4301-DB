#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <algorithm>
#include <vector>
#include <pstl/utils.h>
using namespace std;

void FileToStringFormatter(ifstream& inFile, ofstream& outFile) {
    string formattedString;
    string line;
    vector<string> formattedStrings;
    getline(inFile, line);
    while (getline(inFile, line)) {
        stringstream ss(line);
        string token;
        bool first = true;
        formattedString = "(";
        while (getline(ss, token, ',')) {
            if (!token.empty() && token.front() == '"' && token.back() == '"') {
                token = token.substr(1, token.size() - 2);
                token = token.substr(1, token.size() - 2);
            }
            if (!first) {
                formattedString += ", ";
            }
            formattedString += token;
            first = false;
        }
        formattedString += ")";
        formattedStrings.push_back(formattedString);
    }

    for (int i = 0; i < formattedStrings.size(); ++i) {
        outFile << formattedStrings[i];
        if (i != formattedStrings.size() - 1) {
            outFile << ",\n"; // add comma between rows
        }
    }
    outFile << ";\n\n\n";
    formattedStrings.clear();
    inFile.close();
}



int main() {
    ifstream inFile("../Data/TableSetter.txt");
    ofstream outFile("../Data/SQLText.txt");
    if (!outFile) {
        cerr << "Can't open output file" << endl;
        return 1;
    }
    if (!inFile) {
        cerr << "Error opening file" << endl;
        return 1;
    }
    string line;
    while (getline(inFile, line)) {
        outFile << line << endl;
    }
    outFile << "\n";
    inFile.close();


    //====================== Seasons ======================//

    outFile << "INSERT INTO Season (SeasonYear) VALUES\n(2021),\n(2022),\n(2023);\n\n\n";


    //====================== Teams ======================//

    inFile.open("../Data/TeamsSchemaFormatted.csv");
    outFile << "INSERT INTO Team (TeamID, TeamName, TeamSeason) VALUES\n";
    FileToStringFormatter(inFile, outFile);
    inFile.close();

    //====================== Players ======================//

    inFile.open("../Data/PlayersSchemaFormatted.csv");
    outFile << "INSERT INTO Player (PlayerID, Position, FirstName, LastName) VALUES\n";
    FileToStringFormatter(inFile, outFile);
    inFile.close();

    //====================== PlayerSeason ======================//

    inFile.open("../Data/PlayerSeasonSchemaFormatted.csv");
    outFile << "INSERT INTO PlayerSeason (PlayerID, TeamID, SeasonYear, Salary, WAR) VALUES\n";
    FileToStringFormatter(inFile, outFile);
    inFile.close();

    //====================== Games ======================//

    inFile.open("../Data/GamesSchemaFormatted.csv");
    outFile << "INSERT INTO Game (GameID, GameDate, SeasonYear, Attendance) VALUES\n";
    FileToStringFormatter(inFile, outFile);
    inFile.close();

    //====================== PlayerGame Query ======================//

    inFile.open("../Data/PlayerGameQuery.txt");
    if (!inFile) {
        cerr << "Error opening file" << endl;
        return 1;
    }
    while (getline(inFile, line)) {
        outFile << line << endl;
    }
    outFile << "\n";
    inFile.close();


    return 0;
}